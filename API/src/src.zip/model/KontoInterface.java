/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author Dominik
 */
public interface KontoInterface {

    boolean equals(Object object);

    Date getDataZalozenia();

    String getFirma();

    Integer getIdKonto();

    String getNazwa();

    int hashCode();

    void setDataZalozenia(Date dataZalozenia);

    void setFirma(String firma);

    void setIdKonto(Integer idKonto);

    void setNazwa(String nazwa);

    String toString();
    
}
