/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import javax.ejb.Local;
import model.KontoInterface;
import model.RachunekInterface;

/**
 *
 * @author Dominik
 */
@Local
public interface RachunekFacadeLocal {

    void create(RachunekInterface rachunek);

    void edit(RachunekInterface rachunek);

    void remove(RachunekInterface rachunek);

    RachunekInterface find(Object id);

    List<RachunekInterface> findRange(int[] range);

    int count();

    public List<RachunekInterface> findAccountAccounts(KontoInterface account);

    public RachunekInterface findRachunekByNumber(String number);
    
}
